rootProject.name = "user_details_example"
