package io.example.spring_security.user_details_example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserDetailsExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserDetailsExampleApplication.class, args);
	}

}
