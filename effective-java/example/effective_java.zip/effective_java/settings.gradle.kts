rootProject.name = "effective_java"
