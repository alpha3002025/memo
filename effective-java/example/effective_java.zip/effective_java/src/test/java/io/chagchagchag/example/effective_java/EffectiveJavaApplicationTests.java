package io.chagchagchag.example.effective_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EffectiveJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
