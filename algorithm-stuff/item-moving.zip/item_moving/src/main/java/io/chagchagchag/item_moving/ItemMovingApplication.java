package io.chagchagchag.item_moving;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemMovingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItemMovingApplication.class, args);
	}

}
