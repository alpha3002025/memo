# helloworld1 = "Hello World"
# print(helloworld1.split())

# helloworld2 = "Hello,World"
# print(helloworld2.split(","))

# helloworld3 = "HelloWorld"
# print(f"{[i for i in helloworld3]}")



n = 12345

print([str(num) for num in str(n)].sort())