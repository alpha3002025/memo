

l = [[0] * i for i in [k*2 for k in range(1, 10)]]

print(l)