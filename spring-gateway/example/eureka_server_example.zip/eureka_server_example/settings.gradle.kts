rootProject.name = "eureka_server_example"
