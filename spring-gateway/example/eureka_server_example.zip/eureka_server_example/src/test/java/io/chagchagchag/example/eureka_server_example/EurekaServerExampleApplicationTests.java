package io.chagchagchag.example.eureka_server_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
