package io.chagchagchag.example.prometheus_grafana_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrometheusGrafanaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
