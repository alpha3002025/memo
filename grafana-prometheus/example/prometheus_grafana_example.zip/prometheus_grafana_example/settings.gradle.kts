rootProject.name = "prometheus_grafana_example"
